package service;

import java.util.ArrayList;
import org.springframework.stereotype.Service;

import model.Car;

@Service
public class CarService {
	ArrayList<Car> car = new ArrayList<Car>();

	public CarService() {
		Car c = new Car();
		c.setName("Myvi");
		c.setManufacturer("Perodua");
		car.add(c);

		c = new Car();
		c.setName("Iriz");
		c.setManufacturer("Proton");
		car.add(c);
	}

	public ArrayList<Car> getAll() {
		return car;
	}
}