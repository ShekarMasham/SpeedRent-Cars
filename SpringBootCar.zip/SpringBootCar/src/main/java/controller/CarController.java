package controller;

import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import model.Car;
import service.CarService;

@CrossOrigin
@RestController
@RequestMapping("/cars")
public class CarController {

	@Autowired
	CarService cs;

	@RequestMapping("/hello")
	public ArrayList<Car> getAll() {
		return cs.getAll();
	}
}