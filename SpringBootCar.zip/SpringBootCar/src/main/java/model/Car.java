package model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Car {
	String name;
	String manufacturer;

	public String getName() {
		return name;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

}
